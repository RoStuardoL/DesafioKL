export const users = [{
  id: '1',
  firstName: 'John',
  lastName: 'Doe',
  email: 'john@example.com',
  passwordHash: '$2a$10$XgXB8ZQHm6Zj1wqzPJzp3.1KqLH.4R9RtL9I5QD9kO5wXRqD5IhXy' // password123
}];

export const products = [
  {
    id: '1',
    name: 'Premium Coffee Maker',
    brand: 'BrewMaster',
    category: 'Kitchen Appliances',
    price: 199.99,
    image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085',
    description: 'Professional-grade coffee maker with temperature control.'
  },
  {
    id: '2',
    name: 'Wireless Headphones',
    brand: 'AudioPro',
    category: 'Electronics',
    price: 149.99,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
    description: 'High-quality wireless headphones with noise cancellation.'
  }
];