export const PORT = 5000;
export const JWT_SECRET = 'your-super-secret-key';