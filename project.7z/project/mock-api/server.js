import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const app = express();
const PORT = 5000;
const JWT_SECRET = 'your-super-secret-key';

app.use(cors());
app.use(express.json());

// Mock database
const users = [{
  id: '1',
  firstName: 'John',
  lastName: 'Doe',
  email: 'john@example.com',
  passwordHash: bcrypt.hashSync('password123', 10)
}];

const products = [
  {
    id: '1',
    name: 'Premium Coffee Maker',
    brand: 'BrewMaster',
    category: 'Kitchen Appliances',
    price: 199.99,
    image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085',
    description: 'Professional-grade coffee maker with temperature control.'
  },
  {
    id: '2',
    name: 'Wireless Headphones',
    brand: 'AudioPro',
    category: 'Electronics',
    price: 149.99,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
    description: 'High-quality wireless headphones with noise cancellation.'
  }
];

// Auth middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401);
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.sendStatus(403);
    }
    req.user = user;
    next();
  });
};

// Login endpoint
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);

  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }

  const token = jwt.sign(
    { id: user.id, email: user.email },
    JWT_SECRET,
    { expiresIn: '24h' }
  );

  res.json({
    token,
    user: {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email
    }
  });
});

// Products endpoints
app.get('/api/products', authenticateToken, (req, res) => {
  res.json(products);
});

app.get('/api/products/:id', authenticateToken, (req, res) => {
  const product = products.find(p => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ message: 'Product not found' });
  }
  res.json(product);
});

app.listen(PORT, () => {
  console.log(`Mock API server running on port ${PORT}`);
});