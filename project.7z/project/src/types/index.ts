export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  image: string;
  description: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}